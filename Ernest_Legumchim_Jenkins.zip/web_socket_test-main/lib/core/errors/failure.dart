abstract class Failure {
  String get title;
  String get message;
}
