class SizingConfig {
  static double defaultPadding = 17;
}
